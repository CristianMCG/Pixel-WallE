using Godot;
using System;

public partial class Redimensionar : CodeEdit
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}


	public int getDim()
	{
		return Convert(Text);
	}

	int Convert(string s)  
	{
		int ret = 0;
		int e = 1;
		for(int i = s.Length - 1; i >= 0; i--)   {
			if('0' <= s[i] && s[i] <= '9')  {
				int x = get(s[i]);
				ret += x * e;
				e *= 10;
			}
			else
				return -1;
		}

		if(ret == 0)
			ret = -1;
		return ret;
	}

	int get(char c)
	{
		if(c == '0')
			return 0;
		if(c == '1')
			return 1;
		if(c == '2')
			return 2;
		if(c == '3')
			return 3;
		if(c == '4')
			return 4;
		if(c == '5')
			return 5;
		if(c == '6')
			return 6;
		if(c == '7')
			return 7;
		if(c == '8')
			return 8;
		return 9;
	}

}
