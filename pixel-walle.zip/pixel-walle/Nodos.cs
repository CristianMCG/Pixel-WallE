using System.Collections.Generic;
using System;

public abstract class Nodo
{
    
    public TokenCod cod { get; private set; }
    public Tipo tipo { get; private set; }
    int linea;
    int columna;   
    public TablaDeSimbolos tabla { get; private set; }

    public Nodo(TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla)
    {
        this.cod = cod;
        this.tipo = tipo;
        this.linea = linea;
        this.columna = columna;
        this.tabla = tabla;
    }

    public abstract int Evaluate(ref int iterador);

    public abstract void Mostrar();

}


public class NodoVar : Nodo
{
    public int entradaTS { get; private set; }

    public NodoVar(int entradaTS, TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {
        this.entradaTS = entradaTS;
    }

    public override int Evaluate(ref int iterador)
    {
        Console.WriteLine(((SimboloVar)(tabla.lista[entradaTS])).valor);
        return ((SimboloVar)(tabla.lista[entradaTS])).valor;
    }

    public override void Mostrar()
    {
        Console.WriteLine("Variable <" + tabla.lista[entradaTS].identificador + ">");
    }

}


public class NodoNumberBool : Nodo
{
    int valor;

    public NodoNumberBool(int valor, TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {
        this.valor = valor;
    }

    public override int Evaluate(ref int iterador)
    {
        Console.WriteLine(valor);
        return valor;
    }

    public override void Mostrar()
    {
        Console.WriteLine("NodoNumberBool " + valor);
    }

}

public class NodoStringEtiq : Nodo
{

    public int entradaTS { get; private set; }

    public NodoStringEtiq(int entradaTS, TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {
        this.entradaTS = entradaTS;
    }

    public override int Evaluate(ref int iterador)
    {
        Console.WriteLine(tabla.lista[entradaTS].identificador);
        return entradaTS;
    }

    public override void Mostrar()
    {
        Console.WriteLine("StringEtiq: " + tabla.lista[entradaTS].identificador);
    }

}


public class NodoOp : Nodo
{
    Nodo hizq;
    Nodo der;

    public NodoOp(Nodo hizq, Nodo der, TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {
        this.hizq = hizq;
        this.der = der;
    }

    public override int Evaluate(ref int iterador)
    {
        if(cod == TokenCod.OPFLECHA)   {
            int posVar = ((NodoVar)hizq).entradaTS;
            int valorExpr = der.Evaluate(ref iterador);
            ((SimboloVar)(tabla.lista[posVar])).valor = valorExpr;
            iterador++;
            Console.WriteLine(tabla.lista[posVar].identificador + " <- " + valorExpr);
        }
        if(cod == TokenCod.OPMAS)  
            return hizq.Evaluate(ref iterador) + der.Evaluate(ref iterador);
        if(cod == TokenCod.OPMENOS)
            return hizq.Evaluate(ref iterador) - der.Evaluate(ref iterador);
        if(cod == TokenCod.OPAND)  
            return (hizq.Evaluate(ref iterador) & der.Evaluate(ref iterador));
        if(cod == TokenCod.OPPOR)
            return hizq.Evaluate(ref iterador) * der.Evaluate(ref iterador);
        if(cod == TokenCod.OPDIV)
            return hizq.Evaluate(ref iterador) / der.Evaluate(ref iterador);
        if(cod == TokenCod.OPOR)
            return hizq.Evaluate(ref iterador) | der.Evaluate(ref iterador);
        if(cod == TokenCod.OPPOT)
            return (int)Math.Pow(hizq.Evaluate(ref iterador), der.Evaluate(ref iterador));
        if(cod == TokenCod.OPIGUAL)
            return (hizq.Evaluate(ref iterador) == der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.OPMENOR)
            return(hizq.Evaluate(ref iterador) < der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.OPMENORIGUAL)
            return(hizq.Evaluate(ref iterador) <= der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.OPMAYOR)
            return(hizq.Evaluate(ref iterador) > der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.OPMAYORIGUAL)
            return(hizq.Evaluate(ref iterador) >= der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.PCGOTO)   {
            int pos = hizq.Evaluate(ref iterador);
            int lugarSalto = ((SimboloEtiq)tabla.lista[pos]).valor;
            int cond = der.Evaluate(ref iterador);
            iterador++;
            Console.WriteLine("Cond " + cond);
            Console.WriteLine("Lugar " + lugarSalto);
            if(cond == 1)  {
                iterador = lugarSalto;
                Console.WriteLine("Iterda " + iterador);
            }
        }
        if(cod == TokenCod.OPDISTINTO)   
            return (hizq.Evaluate(ref iterador) != der.Evaluate(ref iterador)) ? 1 : 0;
        if(cod == TokenCod.OPMODULO)
            return hizq.Evaluate(ref iterador) % der.Evaluate(ref iterador);
        if(cod == TokenCod.OPXOR)  
            return (hizq.Evaluate(ref iterador) == der.Evaluate(ref iterador)) ? 0 : 1;

        return 0;
    }

    public override void Mostrar()
    {
        Console.WriteLine("NodoOp: " + cod);
        hizq.Mostrar();
        der.Mostrar();
    }

}



public class NodoFuncion : Nodo
{
    List<Nodo> parametros = new List<Nodo>();
    Canvas canvas;

    public NodoFuncion(List<Nodo> parametros, Canvas canvas, TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {
        this.parametros = parametros;
        this.canvas = canvas;
    }

    public override int Evaluate(ref int iterador)
    {
        if(cod == TokenCod.PCSPAWN)  {
            int x = parametros[0].Evaluate(ref iterador);
            int y = parametros[1].Evaluate(ref iterador);
            canvas.Spawn(x,y);
            iterador++;
            Console.WriteLine("Spawn " + x + " " + y);
        }
        if(cod == TokenCod.PCCOLOR)   {
            int pos = parametros[0].Evaluate(ref iterador);
            string color = ((SimboloString)(tabla.lista[pos])).valor;
            canvas.Color(color);
            iterador++;
            Console.WriteLine("Color " + color);
        }
        if(cod == TokenCod.PCSIZE)   {
            int size = parametros[0].Evaluate(ref iterador);
            canvas.Size(size);
            iterador++;
            Console.WriteLine("Size " + size);
        }
        if(cod == TokenCod.PCDRAWLINE)  {
            int dirX = parametros[0].Evaluate(ref iterador);
            int dirY = parametros[1].Evaluate(ref iterador);
            int distance = parametros[2].Evaluate(ref iterador);
            canvas.DrawLine(dirX, dirY, distance);
            iterador++;
            Console.WriteLine("Drawline " + dirX + " " + dirY + " " + distance);
        }
        if(cod == TokenCod.PCDRAWCIRCLE)   {
            int dirX = parametros[0].Evaluate(ref iterador);
            int dirY = parametros[1].Evaluate(ref iterador);
            int radius = parametros[2].Evaluate(ref iterador);
            canvas.DrawCircle(dirX, dirY, radius);
            iterador++;
            Console.WriteLine("DrawCircle " + dirX + " " + dirY + " " + radius);
        }
        if(cod == TokenCod.PCDRAWRECTANGLE)   {
            int dirX = parametros[0].Evaluate(ref iterador);
            int dirY = parametros[1].Evaluate(ref iterador);
            int distance = parametros[2].Evaluate(ref iterador);
            int width = parametros[3].Evaluate(ref iterador);
            int heigth = parametros[4].Evaluate(ref iterador);
            canvas.DrawRectangle(dirX, dirY, distance, width, heigth);
            iterador++;
            Console.WriteLine("DrawRectangle " + dirX + " " + dirY + " " + distance + " " + width + " " + heigth);
        }
        if(cod == TokenCod.PCFILL)   {
            canvas.Fill();
            iterador++;
        }
        if(cod == TokenCod.PCGETACTUALX)  {
            Console.WriteLine("actual x " + canvas.GetActualX());
            return canvas.GetActualX();
        }
        if(cod == TokenCod.PCGETACTUALY)  
            return canvas.GetActualY();
        if(cod == TokenCod.PCGETCANVASSIZE)  
            return canvas.GetCanvasSize();
        if(cod == TokenCod.PCGETCOLORCOUNT)    {
            int pos = parametros[0].Evaluate(ref iterador);
            string color = ((SimboloString)tabla.lista[pos]).valor;
            int x1 = parametros[1].Evaluate(ref iterador);
            int y1 = parametros[2].Evaluate(ref iterador);
            int x2 = parametros[3].Evaluate(ref iterador);
            int y2 = parametros[4].Evaluate(ref iterador);
            return canvas.GetColorCount(color, x1, y1, x2, y2);
        }
        if(cod == TokenCod.PCISBRUSHCOLOR)  {
            int pos = parametros[0].Evaluate(ref iterador);
            string color = ((SimboloString)tabla.lista[pos]).valor;
            Console.WriteLine("Isbrushcolor " + canvas.IsBrushColor(color));
            return canvas.IsBrushColor(color);
        }
        if(cod == TokenCod.PCISBRUSHSIZE)  {
            int size = parametros[0].Evaluate(ref iterador);
            return canvas.IsBrushSize(size);
        }
        if(cod == TokenCod.PCISCANVASCOLOR)   {
            int pos = parametros[0].Evaluate(ref iterador);
            string color = ((SimboloString)tabla.lista[pos]).valor;
            int vertical = parametros[1].Evaluate(ref iterador);
            int horizontal = parametros[2].Evaluate(ref iterador);
            return canvas.IsCanvasColor(color, vertical, horizontal);
        }
                
        return 0;
    }

    public override void Mostrar()
    {
        Console.WriteLine("Funcion: " + cod);
        for(int i = 0; i < parametros.Count; i++)
            parametros[i].Mostrar();
    }

}

public class NodoVacio : Nodo
{
    public NodoVacio(TokenCod cod, Tipo tipo, int linea, int columna, TablaDeSimbolos tabla) : base(cod, tipo, linea, columna, tabla)
    {

    }

    public override int Evaluate(ref int e)
    {
        e++;
        return 0;
    }

    public override void Mostrar()
    {
        Console.WriteLine("Nodo Vacio");
    }

}
