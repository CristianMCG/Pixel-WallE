using System;

public class Canvas
{

    public Colors[,] canvas;
    int walleX = 0, walleY = 0;
    Colors brushColor = Colors.BLACK;
    int brushSize = 1;

    public Canvas(int length)
    {
        canvas = new Colors[length, length];
        Clear();
    }

    
    public void Spawn(int x, int y)
    {
        if(!InRange(x, 0, canvas.GetLength(0)) || !InRange(y, 0, canvas.GetLength(0)))
            throw new RuntimeException("Variable Fuera De Indice En Spawn: x e y deben ser menor que " + canvas.GetLength(0));
        walleX = x;
        walleY = y;
    }

    public void Color(string color)
    {
        Colors c = getColor(color);
        if(c != Colors.INVALID)
            brushColor = c;
    }

    public void Size(int size)
    {
        if(size % 2 == 1)
            size--;
        brushSize = size;
    }

    public void DrawLine(int dirX, int dirY, int distance)
    {
        while(distance >= 0)    {
            Paint(walleX, walleY);
            walleX += dirX;
            walleY += dirY;
            distance--;
        }
    }

    public void DrawCircle(int dirX, int dirY, int radius)
    {
        walleX += dirX * radius;
        walleY += dirY * radius;
        Circle(walleX, walleY, radius);
    }

    void Circle(int xc, int yc, int radius) 
    {
        int x = 0;
        int y = radius;
        int d = 1 - radius;

        while(x <= y)   {
            Paint(walleX + x, walleY + y);
            Paint(walleX - x, walleY + y);
            Paint(walleX + x, walleY - y);
            Paint(walleX - x, walleY - y);
            Paint(walleX + y, walleY + x);
            Paint(walleX - y, walleY + x);
            Paint(walleX + y, walleY - x);
            Paint(walleX - y, walleY - x);
            x++;
            if(d < 0) 
                d += 2 * x + 1;
            else   {
                y--;
                d += 2 * (x - y) + 1;
            }
        }
    }

    public void DrawRectangle(int dirX, int dirY, int distance, int width, int heigth)
    {
        if(InCanvas(walleX + dirX * distance) && InCanvas(walleY + dirY * distance))  {
            walleX += dirX * distance;
            walleY += dirY * distance;
            for(int i = walleX - width; i <= walleX + width; i++)  {
                if(InCanvas(i, walleY - heigth))
                    Paint(i, walleY - heigth);
                if(InCanvas(i, walleY + heigth))
                    Paint(i, walleY + heigth);
            }
            for(int i = walleY - heigth; i <= walleY + heigth; i++)  {
                if(InCanvas(walleX - width, i))
                    Paint(walleX - width, i);
                if(InCanvas(walleX + width, i))
                    Paint(walleX + width, i);
            }
        }
        else
            Console.WriteLine("No es posible moverse a la posicion <" + walleX + dirX * distance  + "," + 
                walleY + dirY * distance + ">.");
    }

    public void Fill()
    {
        bool[,] visited = new bool[canvas.GetLength(0),canvas.GetLength(0)];
        FillAux(canvas[walleY,walleX], walleX, walleY, visited);
    }

    public void FillAux(Colors color, int x, int y, bool[,] visited)
    {
        canvas[y,x] = brushColor;
        visited[y,x] = true;
        if(x - 1 >= 0 && canvas[y, x - 1] == color && !visited[y, x - 1])
            FillAux(color, x - 1, y, visited);
        if(InCanvas(x + 1) && canvas[y, x + 1] == color && !visited[y, x + 1])
            FillAux(color, x + 1, y, visited);
        if(y - 1 >= 0 && canvas[y - 1, x] == color && !visited[y - 1, x])
            FillAux(color, x, y - 1, visited);
        if(InCanvas(y + 1) && canvas[y + 1, x] == color && !visited[y + 1, x])
            FillAux(color, x, y + 1, visited);
    }

    public int GetActualX()
    {
        return walleX;
    }

    public int GetActualY()
    {
        return walleY;
    }

    public int GetCanvasSize()
    {
        return canvas.GetLength(0);
    }

    public int GetColorCount(string color, int x1, int y1, int x2, int y2)
    {
        Colors c = getColor(color);
        if(!InRange(x1, 0, canvas.GetLength(0)) || !InRange(y1, 0, canvas.GetLength(0)) || !InRange(x2, 0, canvas.GetLength(0)) || !InRange(y2, 0, canvas.GetLength(0)))
            return 0;
        int cnt = 0;
        for(int i = x1; i <= x2; i++)   
            for(int j = y1; j <= y2; j++)   
                if(canvas[i,j] == c)
                    cnt++;
        return cnt;
    }

    public int IsBrushColor(string color)
    {
        Colors c = getColor(color);
        if(c == brushColor)
            return 1;
        return 0;
    }

    public int IsBrushSize(int size)
    {
        return (size == brushSize) ? 1 : 0;
    }

    public int IsCanvasColor(string color, int vertical, int horizontal)
    {
        if(!InRange(walleX + vertical, 0, canvas.GetLength(0)) || !InRange(walleY + horizontal, 0, canvas.GetLength(0)))
            return 0;
        Colors c = getColor(color);
        if(canvas[walleX + vertical, walleY + horizontal] == c)
            return 1;
        return 0;
    }

    bool InRange(int x, int l, int r)
    {
        return (l <= x && x < r) ? true : false;
    }

    bool InCanvas(int x)
    {
        return(0 <= x && x < canvas.GetLength(0)) ? true : false;
    }

    bool InCanvas(int x, int y)
    {
        return(0 <= x && x < canvas.GetLength(0) && 0 <= y && y < canvas.GetLength(0)) ? true : false;
    }

    public Colors pos(int x, int y)  
    {
        return canvas[x,y];
    }

    public void Clear()
    {
        for(int i = 0; i < canvas.GetLength(0); i++)
            for(int j = 0; j < canvas.GetLength(0); j++)
                canvas[i,j] = Colors.WHITE;
        
    }

    Colors getColor(string color)
    {   
        color = color.ToLower();
        if(color == "red")
            return Colors.RED;
        if(color == "blue")
            return Colors.BLUE;
        if(color == "green")
            return Colors.GREEN;
        if(color == "yellow")
            return Colors.YELLOW;
        if(color == "orange")
            return Colors.ORANGE;
        if(color == "purple")
            return Colors.PURPLE;
        if(color == "black")
            return Colors.BLACK;
        if(color == "white")
            return Colors.WHITE;
        if(color == "transparent")
            return Colors.TRANSPARENT;
        return Colors.INVALID;
    }

    void Paint(int X, int Y)
    {
        int idx = (brushSize - 1) / 2;
        for(int i = X - idx; i <= X + idx; i++)
            for(int j = Y - idx; j <= Y + idx; j++)
                if(InCanvas(i) && InCanvas(j) && brushColor != Colors.TRANSPARENT)
                    canvas[j,i] = brushColor;
    }

}

public enum Colors
{
    RED, BLUE, GREEN, YELLOW, ORANGE, PURPLE, BLACK, WHITE, TRANSPARENT, INVALID
}