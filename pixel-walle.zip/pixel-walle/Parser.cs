using System.Collections.Generic;
using System;

public class Parser
{
    Scanner scanner;
    Token lookAtHead;
    List<Nodo> rte = new List<Nodo>();
    Canvas canvas;
    TablaDeSimbolos tabla;

    public Parser(Scanner scanner, Canvas canvas, TablaDeSimbolos tabla)
    {
        this.scanner = scanner;
        this.canvas = canvas;
        lookAtHead = scanner.GetNextToken();
        this.tabla = tabla;
    }

    void Match(TokenCod cod)
    {
        if(lookAtHead.cod == cod)   {
            lookAtHead = scanner.GetNextToken();
            if(lookAtHead.cod == TokenCod.ERROR)
                throw new LexicalException((TokenError)lookAtHead);
        }
        else    {
            throw new SintacticException(lookAtHead, "Token <" + lookAtHead.cod + "> Erroneo. Se Esperaba <" + cod + ">");
        }
    }

    bool Buscar(TokenCod[] cods)
    {
        for(int i = 0; i < cods.Length; i++)  
            if(cods[i] == lookAtHead.cod)
                return true;
        return false;
    }

    public List<Nodo> Parse()
    {
        Lenguaje();
        return rte;
    }

    //<lenguaje> -> <comandoSpawn> <listaInstr> ;
    void Lenguaje()
    {
        if(lookAtHead.cod == TokenCod.PCSPAWN)  {
            Nodo spawn = ComandoSpawn();
            rte.Add(spawn);
            ListaInstr();
            Match(TokenCod.FINAL);
        }
        else
            throw new SintacticException(lookAtHead, "El Codigo Debe Comenzar Con El Comando Spawn");
    }

    //<comandoSpawn> -> PCSPAWN <PosSpawn> ;     
    Nodo ComandoSpawn()
    {
        if(lookAtHead.cod == TokenCod.PCSPAWN)    {
            Match(TokenCod.PCSPAWN);
            return PosSpawn();
        }
        else
            throw new SintacticException(lookAtHead, "El Codigo Debe Comenzar Con El Comando Spawn");
    }

    //<PosSpawn> -> PARAB <expr> COMA <expr> PARCER;

    Nodo PosSpawn()
    {
        if(lookAtHead.cod == TokenCod.PARAB)  {
            List<Nodo> lista = new List<Nodo>();
            Match(TokenCod.PARAB);
            Token aux = lookAtHead;
            Nodo expr1 = Expr();
            if(expr1.tipo == Tipo.BOOL)
                throw new SemanticException(aux, "Los Parametros De Spawn Deben Ser Enteros");
            Match(TokenCod.COMA);
            aux = lookAtHead;
            Nodo expr2 = Expr();
            if(expr2.tipo == Tipo.BOOL)
                throw new SemanticException(aux, "Los Parametros De Spawn Deben Ser Enteros");
            lista.Add(expr1);
            lista.Add(expr2);
            Match(TokenCod.PARCER);
            return new NodoFuncion(lista, canvas, TokenCod.PCSPAWN, Tipo.NULL, -1, -1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Se Esperaba (");
    }

    //<listaInstr> -> <listaInstrD> ;
    void ListaInstr()
    {
        ListaInstrD();
    }

    /*
        <listaInstrD> -> NEWLINE <instr> <listaInstrD> |
	    ;
    */
    void ListaInstrD()
    {
        if(lookAtHead.cod == TokenCod.NEWLINE)   {
            Match(TokenCod.NEWLINE);
            Nodo instr = Instr();
            if(instr is NodoStringEtiq)  { 
                ((SimboloEtiq)tabla.lista[((NodoStringEtiq)instr).entradaTS]).valor = rte.Count;
                tabla.lista[((NodoStringEtiq)instr).entradaTS].isNull = false;
            }
            else
                rte.Add(instr);
            ListaInstrD();
        }
        else if(lookAtHead.cod == TokenCod.FINAL)  {}
        else
            throw new SintacticException(lookAtHead, "Cambio De Linea O Fin De Programa Esperados");
    }

    /*
        <instr> -> <comando> |
	    <asign> |
	    <etiq> |
    	<saltoCond> |
        ;
    */

    Nodo Instr()
    {
        TokenCod[] cjto1 = {TokenCod.PCCOLOR, TokenCod.PCSIZE, TokenCod.PCDRAWLINE, TokenCod.PCDRAWCIRCLE, TokenCod.PCDRAWRECTANGLE, TokenCod.PCFILL};
        TokenCod[] cjto2 = {TokenCod.NEWLINE, TokenCod.FINAL};
        if(Buscar(cjto1))
            return Comando();
        else if(lookAtHead.cod == TokenCod.VAR)
            return Asign();
        else if(lookAtHead.cod == TokenCod.ETIQ)
            return Etiq();
        else if(lookAtHead.cod == TokenCod.PCGOTO)
            return SaltoCond();
        else if(Buscar(cjto2))   {
            return new NodoVacio(TokenCod.FINAL, Tipo.NULL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Comando, Variable, Etiqueta O Instruccion Goto Esperado");
    }

    /*
        <comando> -> PCCOLOR PARAB STRING PARCER |
	        PCSIZE PARAB <expr> PARCER |
	        PCDRAWLINE PARAB <expr> COMA <expr> COMA <expr> PARCER |
   	        PCDRAWCIRCLE PARAB <expr> COMA <expr> COMA <expr> PARCER |
	        PCDRAWRECTANGLE PARAB <expr> COMA <expr> COMA <expr> COMA <expr> COMA <expr> PARCER |
   	        PCFILL PARAB PARCER;
    */

    Nodo Comando()
    {
        List<Nodo> lista = new List<Nodo>();
        if(lookAtHead.cod == TokenCod.PCCOLOR)   {
            Match(TokenCod.PCCOLOR);
            Match(TokenCod.PARAB);
            Nodo string1 = String();
            Match(TokenCod.PARCER);
            lista.Add(string1);
            return new NodoFuncion(lista, canvas, TokenCod.PCCOLOR, Tipo.NULL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCSIZE)  {
            Match(TokenCod.PCSIZE);
            Match(TokenCod.PARAB);
            Token token = lookAtHead;
            Nodo DatoEnt1 = Expr();
            if(DatoEnt1.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.PARCER);
            lista.Add(DatoEnt1);
            return new NodoFuncion(lista, canvas, TokenCod.PCSIZE, Tipo.NULL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCDRAWLINE)   {
            Match(TokenCod.PCDRAWLINE);
            Match(TokenCod.PARAB);
            Token token = lookAtHead;
            Nodo DatoEnt1 = Expr();
            if(DatoEnt1.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt2 = Expr();
            if(DatoEnt2.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt3 = Expr();
            if(DatoEnt3.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.PARCER);
            lista.Add(DatoEnt1);
            lista.Add(DatoEnt2);
            lista.Add(DatoEnt3);
            return new NodoFuncion(lista, canvas, TokenCod.PCDRAWLINE, Tipo.NULL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCDRAWCIRCLE)    {
            Match(TokenCod.PCDRAWCIRCLE);
            Match(TokenCod.PARAB);
            Token token = lookAtHead;
            Nodo DatoEnt1 = Expr();
            if(DatoEnt1.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt2 = Expr();
            if(DatoEnt2.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt3 = Expr();
            if(DatoEnt3.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.PARCER);
            lista.Add(DatoEnt1);
            lista.Add(DatoEnt2);
            lista.Add(DatoEnt3);
            return new NodoFuncion(lista, canvas, TokenCod.PCDRAWCIRCLE, Tipo.NULL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCDRAWRECTANGLE)   {
            Match(TokenCod.PCDRAWRECTANGLE);
            Match(TokenCod.PARAB);
            Token token = lookAtHead;
            Nodo DatoEnt1 = Expr();
            if(DatoEnt1.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt2 = Expr();
            if(DatoEnt2.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt3 = Expr();
            if(DatoEnt3.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt4 = Expr();
            if(DatoEnt4.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.COMA);
            token = lookAtHead;
            Nodo DatoEnt5 = Expr();
            if(DatoEnt5.tipo != Tipo.INT)
                throw new SemanticException(token, "Se esperaba una expresion entera.");
            Match(TokenCod.PARCER);
            lista.Add(DatoEnt1);
            lista.Add(DatoEnt2);
            lista.Add(DatoEnt3);
            lista.Add(DatoEnt4);
            lista.Add(DatoEnt5);
            return new NodoFuncion(lista, canvas, TokenCod.PCDRAWRECTANGLE, Tipo.NULL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCFILL)   {
            Match(TokenCod.PCFILL);
            Match(TokenCod.PARAB);
            Match(TokenCod.PARCER);
            return new NodoFuncion(lista, canvas, TokenCod.PCFILL, Tipo.NULL, -1, -1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Comando Esperado");
    }

    //<asign> -> VAR OPFLECHA <expr> ;
    Nodo Asign()
    {
        if(lookAtHead.cod == TokenCod.VAR)   {
            Token token = lookAtHead;
            Match(TokenCod.VAR);
            Nodo variable = new NodoVar(((TokenVar)token).entradaTS, TokenCod.VAR, tabla.lista[((TokenVar)token).entradaTS].tipo, token.linea, token.columna, tabla);
            Match(TokenCod.OPFLECHA);
            Nodo expr = Expr();
            tabla.lista[((TokenVar)token).entradaTS].tipo = expr.tipo;
            tabla.lista[((TokenVar)token).entradaTS].isNull = false;
            return new NodoOp(variable, expr, TokenCod.OPFLECHA, expr.tipo, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Variable Esperada");
    }

    //<expr> ->	<AndBool> <exprD> ;
    Nodo Expr()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.NUMBER, TokenCod.PARAB,
            TokenCod.PCGETACTUALX, TokenCod.PCGETACTUALY, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT,
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISBRUSHSIZE, TokenCod.PCISCANVASCOLOR,
            TokenCod.PCTRUE, TokenCod.PCFALSE, TokenCod.PARAB};
        if(Buscar(cjto1))   {
            Nodo and1 = AndBool();  
            return ExprD(and1);
        }
        else
            throw new SintacticException(lookAtHead, "Termino esperado (var, numero, funcion, true, false, parentesis abierto)");
    }


    // <exprD> -> OPAND <AndBool> <exprD> | ;
    Nodo ExprD(Nodo and1)
    {
        TokenCod[] cjto = {TokenCod.FINAL, TokenCod.COMA, TokenCod.PARCER, TokenCod.NEWLINE };
        if(lookAtHead.cod == TokenCod.OPAND)  {
            Token token = lookAtHead;
            Match(TokenCod.OPAND);
            Nodo and2 = AndBool();
            if(and1.tipo != Tipo.BOOL || and2.tipo != Tipo.BOOL)
                throw new SemanticException(token, "El operador && debe operar con valores booleanos.");
            NodoOp and = new NodoOp(and1, and2, TokenCod.OPAND, Tipo.BOOL, 1, 1, tabla);
            return ExprD(and);
        }
        else if(Buscar(cjto))   {
            return and1;
        }
        else
            throw new SintacticException(lookAtHead, "&&, coma, ), nueva linea o fin de programa esperado.");
    }


    // <AndBool> -> <OrBool> <AndBoolD> ;
    Nodo AndBool()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.NUMBER, TokenCod.PARAB,
            TokenCod.PCGETACTUALX, TokenCod.PCGETACTUALY, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT,
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISBRUSHSIZE, TokenCod.PCISCANVASCOLOR,
            TokenCod.PCTRUE, TokenCod.PCFALSE, TokenCod.PARAB};
        if(Buscar(cjto1))   {
            Nodo or1 = OrBool();
            return AndBoolD(or1);
        }
        else
            throw new SintacticException(lookAtHead, "Termino esperado (var, numero, funcion, true, false, parentesis abierto)");
    }


    // <AndBoolD> -> OPOR <OrBool> <AndBoolD> | ;
    Nodo AndBoolD(Nodo or1)   
    {
        TokenCod[] cjto = {TokenCod.FINAL, TokenCod.COMA, TokenCod.OPAND, TokenCod.PARCER, TokenCod.NEWLINE};
        if(lookAtHead.cod == TokenCod.OPOR)   {
            Token token = lookAtHead;
            Match(TokenCod.OPOR);
            Nodo or2 = OrBool();
            if(or1.tipo != Tipo.BOOL || or2.tipo != Tipo.BOOL)
                throw new SemanticException(token, "El operador || debe operar con valores booleanos.");
            NodoOp or = new NodoOp(or1, or2, TokenCod.OPOR, Tipo.BOOL, 1, 1, tabla);
            return AndBoolD(or);
        }
        else if(Buscar(cjto))   
            return or1;
        else
            throw new SintacticException(lookAtHead, "||, &&, coma, ), nueva linea o fin de programa esperado.");
    }


    // <OrBool> -> <parteExpr> <OrBoolD> ;
    Nodo OrBool()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.NUMBER, TokenCod.PARAB,
            TokenCod.PCGETACTUALX, TokenCod.PCGETACTUALY, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT,
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISBRUSHSIZE, TokenCod.PCISCANVASCOLOR,
            TokenCod.PCTRUE, TokenCod.PCFALSE, TokenCod.PARAB};
        if(Buscar(cjto1))   {
            Nodo parte1 = ParteExpr();
            return OrBoolD(parte1);
        }
        else
            throw new SintacticException(lookAtHead, "Termino esperado (var, numero, funcion, true, false, parentesis abierto)");
    }

    // <OrBoolD> -> <opRel> <parteExpr> <OrBoolD> | ;
    Nodo OrBoolD(Nodo parte1)
    {
        TokenCod[] cjto1 = {TokenCod.OPIGUAL, TokenCod.OPMAYOR, TokenCod.OPMENOR, TokenCod.OPDISTINTO, 
                TokenCod.OPMAYORIGUAL, TokenCod.OPMENORIGUAL};
        TokenCod[] cjto2 = {TokenCod.FINAL, TokenCod.COMA, TokenCod.OPOR, TokenCod.OPAND, TokenCod.PARCER, TokenCod.NEWLINE};
        if(Buscar(cjto1))   {
            Token token = lookAtHead;
            Nodo op = OpRel();
            Nodo parte2 = ParteExpr();
            if((op.cod == TokenCod.OPIGUAL || op.cod == TokenCod.OPDISTINTO) && parte1.tipo != parte2.tipo)    
                throw new SemanticException(token, "Los operadores == y != deben operar con datos del mismo tipo.");
            if((op.cod != TokenCod.OPIGUAL && op.cod != TokenCod.OPDISTINTO) && (parte1.tipo != Tipo.INT || parte2.tipo != Tipo.INT))
                throw new SemanticException(token, "Los operadores <, <=, >, >=  deben operar con enteros.");
            NodoOp comp = new NodoOp(parte1, parte2, op.cod, Tipo.BOOL, 1, 1, tabla);
            return OrBoolD(comp);
        }
        else if(Buscar(cjto2))   
            return parte1;
        else
            throw new SintacticException(lookAtHead, "Se esperaba una comparacion, coma, ||, &&, ), nueva linea o fin de programa");
    }


    // <parteExpr> -> <term> <parteExprD> ;
    Nodo ParteExpr()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.NUMBER, TokenCod.PARAB,
            TokenCod.PCGETACTUALX, TokenCod.PCGETACTUALY, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT,
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISBRUSHSIZE, TokenCod.PCISCANVASCOLOR,
            TokenCod.PCTRUE, TokenCod.PCFALSE, TokenCod.PARAB};        
        if(Buscar(cjto1))   {
            Nodo term1 = Term();
            return ParteExprD(term1);
        }
        else
            throw new SintacticException(lookAtHead, "Termino esperado (var, numero, funcion, true, false, parentesis abierto)");
    }

    //<parteExprD> -> <opMasMenos> <term> <parteExprD> | ;

    Nodo ParteExprD(Nodo term1)
    {
        TokenCod[] cjto1 = {TokenCod.OPMAS, TokenCod.OPMENOS};
        TokenCod[] cjto2 = {TokenCod.FINAL, TokenCod.COMA, TokenCod.OPOR, TokenCod.OPAND, TokenCod.PARCER, TokenCod.NEWLINE, 
            TokenCod.OPIGUAL, TokenCod.OPMAYOR, TokenCod.OPMENOR, TokenCod.OPDISTINTO, TokenCod.OPMAYORIGUAL, 
            TokenCod.OPMENORIGUAL };
        if(Buscar(cjto1))   {
            Token token = lookAtHead;
            Nodo op = OpMasMenos();
            Nodo term2 = Term();
            if(term1.tipo != Tipo.INT || term2.tipo != Tipo.INT)
                throw new SemanticException(token, "Los operadores + y - deben operar con enteros.");
            NodoOp nodo = new NodoOp(term1, term2, op.cod, Tipo.INT, 1, 1, tabla);
            return ParteExprD(nodo);
        }
        else if(Buscar(cjto2))  
            return term1;
        else
            throw new SintacticException(lookAtHead, "Se esperaba +, -, comparacion, coma, ||, &&, ), nueva linea o fin de programa");
    }

    //<term> -> <factor> <termD> ;
    Nodo Term()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.PARAB, TokenCod.NUMBER, 
            TokenCod.PCGETACTUALX, TokenCod.PCGETACTUALY, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT,
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISBRUSHSIZE, TokenCod.PCISCANVASCOLOR,
            TokenCod.PCTRUE, TokenCod.PCFALSE, TokenCod.PARAB};
        if(Buscar(cjto1))  {
            Nodo factor1 = Factor();
            return TermD(factor1);
        }
        else
            throw new SintacticException(lookAtHead, "Var, numero, funcion, true, false o '(' esperados");
    }

    /*
        <termD> -> <opPorDivOr> <factor> <termD> | 
	    ;
    */
    Nodo TermD(Nodo factor1)
    {
        TokenCod[] cjto1 = {TokenCod.OPPOR, TokenCod.OPDIV, TokenCod.OPMODULO};
        TokenCod[] cjto2 = {TokenCod.NEWLINE, TokenCod.FINAL, TokenCod.OPAND, TokenCod.OPOR, TokenCod.OPMAS, 
                    TokenCod.OPMENOS,
                            TokenCod.PARCER, TokenCod.COMA, TokenCod.OPMAYOR, TokenCod.OPDISTINTO,
                TokenCod.OPMAYORIGUAL, TokenCod.OPMENOR, TokenCod.OPMENORIGUAL, TokenCod.OPIGUAL};
        if(Buscar(cjto1))  {
            Token token = lookAtHead;
            Nodo op = OpPorDiv();
            Nodo factor2 = Factor();
            if(factor1.tipo != Tipo.INT || factor2.tipo != Tipo.INT)   
                throw new SemanticException(token, "Las operaciones *, / y % deben operar con enteros.");
            NodoOp term = new NodoOp(factor1, factor2, op.cod, factor1.tipo, 1, 1, tabla);
            return TermD(term);
        }
        else if(Buscar(cjto2))   {
            return factor1;
        }
        else
            throw new SintacticException(lookAtHead, "*, /, ||, +, -, &&, \\n o fin de programa esperados");
    }


    //<factor> -> <datoLit> <factorD> ;
    Nodo Factor()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.NOT, TokenCod.PARAB, TokenCod.NUMBER, TokenCod.PCTRUE, TokenCod.PCFALSE, 
            TokenCod.PCGETACTUALY, TokenCod.PCGETACTUALX, TokenCod.PCISBRUSHSIZE, TokenCod.PCISBRUSHCOLOR, 
            TokenCod.PCISCANVASCOLOR, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT};
        if(Buscar(cjto1))  {
            Nodo dato1 = DatoLit();
            return FactorD(dato1);
        }
        else
            throw new SintacticException(lookAtHead, "Var, '(', Numero, true, false o funcion esperados");
    }

    /*
        <factorD> -> OPPOT <datoLit> <factorD> | 
	    ;
    */
    Nodo FactorD(Nodo dato1)
    {
        TokenCod[] cjto2 = {TokenCod.FINAL, TokenCod.OPOR, TokenCod.OPAND, TokenCod.OPMAS, TokenCod.OPPOR, TokenCod.OPMODULO, 
            TokenCod.OPDIV, TokenCod.NEWLINE, TokenCod.OPMENOS, TokenCod.PARCER, TokenCod.COMA, TokenCod.OPMAYOR, 
                TokenCod.OPMAYORIGUAL, TokenCod.OPMENOR, TokenCod.OPMENORIGUAL, TokenCod.OPIGUAL, TokenCod.OPDISTINTO};    
        if(lookAtHead.cod == TokenCod.OPPOT)  {
            Token token = lookAtHead;
            Match(TokenCod.OPPOT);
            Nodo dato2 = DatoLit();
            if(dato2.tipo != Tipo.INT || dato1.tipo != Tipo.INT)   
                throw new SemanticException(token, "Las operacion ** deben operar con enteros.");
            NodoOp factor = new NodoOp(dato1, dato2, TokenCod.OPPOT, dato1.tipo, 1, 1, tabla);
            return FactorD(factor);
        }
        else if(Buscar(cjto2))   {
            return dato1;
        }
        else
            throw new SintacticException(lookAtHead, "||, &&, +, , -, *, /, Cambio de linea o fin de programa esperados");
    }

    //  <datoLit> -> <dato> | NOT <dato>;
    Nodo DatoLit()
    {
        TokenCod[] cjto1 = {TokenCod.VAR, TokenCod.PARAB, TokenCod.NUMBER, TokenCod.PCTRUE, TokenCod.PCFALSE, 
            TokenCod.PCGETACTUALY, TokenCod.PCGETACTUALX, TokenCod.PCISBRUSHSIZE, TokenCod.PCISBRUSHCOLOR, 
            TokenCod.PCISCANVASCOLOR, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT};
        if(Buscar(cjto1))  
            return Dato();
        else if(lookAtHead.cod == TokenCod.NOT)   {
            Token token = lookAtHead;
            Match(TokenCod.NOT);
            Nodo dato = Dato();
            if(dato.tipo != Tipo.BOOL)
                throw new SemanticException(token, "El operador ! solo se puede usar con expresiones booleanas.");
            NodoNumberBool uno = new NodoNumberBool(1, TokenCod.NUMBER, Tipo.INT, 1, 1, tabla);
            NodoOp op = new NodoOp(dato, uno, TokenCod.OPXOR, Tipo.BOOL, 1, 1, tabla);
            return op;
        }
        else
            throw new SintacticException(lookAtHead, "Variable, !, numero, Funcion, true o false esperados");
    }

    /*
        <dato> -> VAR |
	    NUMBER |
	    <funcion> |
	    <datoBool> |
        PARAB <expr> PARCER;
    */
    Nodo Dato()
    {
        TokenCod[] cjto3 = {TokenCod.PCGETACTUALY, TokenCod.PCGETACTUALX, TokenCod.PCISBRUSHSIZE, 
            TokenCod.PCISBRUSHCOLOR, TokenCod.PCISCANVASCOLOR, TokenCod.PCGETCANVASSIZE, TokenCod.PCGETCOLORCOUNT};
        TokenCod[] cjto4 = {TokenCod.PCTRUE, TokenCod.PCFALSE };
        if(lookAtHead.cod == TokenCod.VAR)  {
            Token token = lookAtHead;
            Match(TokenCod.VAR);
            if(tabla.lista[((TokenVar)token).entradaTS].isNull)
                throw new SemanticException(token, "Variable <" + tabla.lista[((TokenVar)token).entradaTS].identificador + "> no definida.");
            return new NodoVar(((TokenVar)token).entradaTS, TokenCod.VAR, tabla.lista[((TokenVar)token).entradaTS].tipo, token.linea, token.columna, tabla);
        }
        else if(lookAtHead.cod == TokenCod.NUMBER)   {
            TokenNumberBool token = (TokenNumberBool)lookAtHead;
            Match(TokenCod.NUMBER);
            return new NodoNumberBool(token.valor, TokenCod.NUMBER, Tipo.INT, 1, 1, tabla);
        }
        else if(Buscar(cjto3))  
            return Funcion();
        else if(Buscar(cjto4))   
            return DatoBool();
        else if(lookAtHead.cod == TokenCod.PARAB)   {
            Match(TokenCod.PARAB);
            Nodo expr = Expr();
            Match(TokenCod.PARCER);
            return expr;
        }
        else 
            throw new SintacticException(lookAtHead, "Variable, numero, Funcion, true o false esperados");
    }

    /*
        <datoBool> -> PCTRUE | PCFALSE;
    */
    Nodo DatoBool()
    {
        if(lookAtHead.cod == TokenCod.PCTRUE)  {
            Match(TokenCod.PCTRUE);
            return new NodoNumberBool(1, TokenCod.PCTRUE, Tipo.BOOL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCFALSE)   {
            Match(TokenCod.PCFALSE);
            return new NodoNumberBool(0, TokenCod.PCTRUE, Tipo.BOOL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "true o false  esperados");
    }

    /*
        <datoEnt> -> VAR | 
	    NUMBER ;
    */
    Nodo DatoEnt()
    {
        Token token = lookAtHead;
        if(lookAtHead.cod == TokenCod.VAR)  {
            Match(TokenCod.VAR);
            if(tabla.lista[((TokenVar)token).entradaTS].isNull)
                throw new SemanticException(token, "Variable <" + tabla.lista[((TokenVar)token).entradaTS].identificador + "> no definida.");
            return new NodoVar(((TokenVar)token).entradaTS, TokenCod.VAR, tabla.lista[((TokenVar)token).entradaTS].tipo, token.linea, token.columna, tabla);
        }
        else if(lookAtHead.cod == TokenCod.NUMBER)   {
            Match(TokenCod.NUMBER);
            return new NodoNumberBool(((TokenNumberBool)token).valor, TokenCod.NUMBER, (token.cod == TokenCod.PCTRUE || token.cod == TokenCod.PCFALSE) ? Tipo.BOOL : Tipo.INT, token.linea, token.columna, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Variable o numero esperados");  
    }

    /*
        <opMasMenos> -> OPMAS | 
	    OPMENOS ;
    */
    Nodo OpMasMenos()
    {
        NodoVar vacio = new NodoVar(0, TokenCod.FINAL, Tipo.NULL, 1, 1, tabla);
        if(lookAtHead.cod == TokenCod.OPMAS)  {
            Match(TokenCod.OPMAS);
            return new NodoOp(vacio, vacio, TokenCod.OPMAS, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMENOS)  {
            Match(TokenCod.OPMENOS);
            return new NodoOp(vacio, vacio, TokenCod.OPMENOS, Tipo.NULL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "+ o - esperados");
    }

    /*
        <opPorDivOr> -> OPPOR | 
	    OPDIV ;
    */
    Nodo OpPorDiv()
    {
        NodoVar vacio = new NodoVar(0, TokenCod.FINAL, Tipo.NULL, 1, 1, tabla);
        if(lookAtHead.cod == TokenCod.OPPOR)  {
            Match(TokenCod.OPPOR);
            return new NodoOp(vacio, vacio, TokenCod.OPPOR, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPDIV)  {
            Match(TokenCod.OPDIV);
            return new NodoOp(vacio, vacio, TokenCod.OPDIV, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMODULO)   {
            Match(TokenCod.OPMODULO);
            return new NodoOp(vacio, vacio, TokenCod.OPMODULO, Tipo.NULL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "*, / o % esperados"); 
    }

    /*
        <opRel> -> OPIGUAL | 
	    OPMAYORIGUAL | 
	    OPMENORIGUAL | 
	    OPMAYOR | 
	    OPMENOR |
        OPDISTINTO ;
    */
    Nodo OpRel()
    {
        NodoVar vacio = new NodoVar(0, TokenCod.FINAL, Tipo.NULL, 1, 1, tabla);
        if(lookAtHead.cod == TokenCod.OPIGUAL)   {
            Match(TokenCod.OPIGUAL);
            return new NodoOp(vacio, vacio, TokenCod.OPIGUAL, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMAYORIGUAL)  {
            Match(TokenCod.OPMAYORIGUAL);
            return new NodoOp(vacio, vacio, TokenCod.OPMAYORIGUAL, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMENORIGUAL)   {
            Match(TokenCod.OPMENORIGUAL);
            return new NodoOp(vacio, vacio, TokenCod.OPMENORIGUAL, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMAYOR)   {
            Match(TokenCod.OPMAYOR);
            return new NodoOp(vacio, vacio, TokenCod.OPMAYOR, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPMENOR)       {
            Match(TokenCod.OPMENOR);
            return new NodoOp(vacio, vacio, TokenCod.OPMENOR, Tipo.NULL, 1, 1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.OPDISTINTO)   {
            Match(TokenCod.OPDISTINTO);
            return new NodoOp(vacio, vacio, TokenCod.OPDISTINTO, Tipo.NULL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "==, >=, <=, > o < esperados"); 
    }

    /*
        <funcion> -> PCGETACTUALX PARAB PARCER |
	    PCGETACTUALY PARAB PARCER |
	    PCGETCANVASSIZE PARAB PARCER |
	    PCGETCOLORCOUNT PARAB <String> COMA <expr> COMA <expr> COMA <expr> COMA <expr> PARCER |
	    PCISBRUSHCOLOR PARAB <String> PARCER |
	    PCISBRUSHSIZE PARAB <expr> PARCER |
	    PCISCANVASCOLOR PARAB <String> COMA <expr> COMA <expr> PARCER ;
    */
    Nodo Funcion()
    {
        List<Nodo> lista = new List<Nodo>();
        if(lookAtHead.cod == TokenCod.PCGETACTUALX)  {
            Match(TokenCod.PCGETACTUALX);
            Match(TokenCod.PARAB);
            Match(TokenCod.PARCER);
            return new NodoFuncion(lista, canvas, TokenCod.PCGETACTUALX, Tipo.INT, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCGETACTUALY)  {
            Match(TokenCod.PCGETACTUALY);
            Match(TokenCod.PARAB);
            Match(TokenCod.PARCER);
            return new NodoFuncion(lista, canvas, TokenCod.PCGETACTUALY, Tipo.INT, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCGETCANVASSIZE)  {
            Match(TokenCod.PCGETCANVASSIZE);
            Match(TokenCod.PARAB);
            Match(TokenCod.PARCER);
            return new NodoFuncion(lista, canvas, TokenCod.PCGETCANVASSIZE, Tipo.INT, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCGETCOLORCOUNT)  {
            Match(TokenCod.PCGETCOLORCOUNT);
            Match(TokenCod.PARAB);
            Nodo string1 = String();
            Match(TokenCod.COMA);
            Nodo DatoEnt1 = Expr();
            Match(TokenCod.COMA);
            Nodo DatoEnt2 = Expr();
            Match(TokenCod.COMA);
            Nodo DatoEnt3 = Expr();
            Match(TokenCod.COMA);
            Nodo DatoEnt4 = Expr();
            Match(TokenCod.PARCER);
            lista.Add(string1);
            lista.Add(DatoEnt1);
            lista.Add(DatoEnt2);
            lista.Add(DatoEnt3);
            lista.Add(DatoEnt4);
            return new NodoFuncion(lista, canvas, TokenCod.PCGETCOLORCOUNT, Tipo.INT, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCISBRUSHCOLOR)  {
            Match(TokenCod.PCISBRUSHCOLOR);
            Match(TokenCod.PARAB);
            Nodo string1 = String();
            Match(TokenCod.PARCER);
            lista.Add(string1);
            return new NodoFuncion(lista, canvas, TokenCod.PCISBRUSHCOLOR, Tipo.BOOL, -1, -1, tabla);
        }
        else if(lookAtHead.cod == TokenCod.PCISBRUSHSIZE)  {
            Match(TokenCod.PCISBRUSHSIZE);
            Match(TokenCod.PARAB);
            Nodo DatoEnt1 = Expr();
            Match(TokenCod.PARCER);
            lista.Add(DatoEnt1);
            return new NodoFuncion(lista, canvas, TokenCod.PCISBRUSHSIZE, Tipo.BOOL, -1, -1, tabla);
        }
	    else if(lookAtHead.cod == TokenCod.PCISCANVASCOLOR)  {
            Match(TokenCod.PCISCANVASCOLOR);
            Match(TokenCod.PARAB);
            Nodo string1 = String();
            Match(TokenCod.COMA);
            Nodo DatoEnt1 = Expr();
            Match(TokenCod.COMA);
            Nodo DatoEnt2 = Expr();
            Match(TokenCod.PARCER);
            lista.Add(string1);
            lista.Add(DatoEnt1);
            lista.Add(DatoEnt2);
            return new NodoFuncion(lista, canvas, TokenCod.PCISCANVASCOLOR, Tipo.BOOL, -1, -1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Funcion Esperada"); 
    }

    /*
        <saltoCond> -> PCGOTO CORCHAB <Etiq> CORCHCER <CondicionGoto> 
    */
    Nodo SaltoCond()
    {
        if(lookAtHead.cod == TokenCod.PCGOTO)  {
            Match(TokenCod.PCGOTO);
            Match(TokenCod.CORCHAB);
            Nodo string1 = Etiq();
            Match(TokenCod.CORCHCER);
            Nodo cond = CondicionGoto();
            return new NodoOp(string1, cond, TokenCod.PCGOTO, Tipo.NULL, 1, 1, tabla);
        }
        else
           throw new SintacticException(lookAtHead, "Goto Esperado");  
    }

    /*
        <Etiq> -> ETIQ;
    */
    Nodo Etiq()
    {
        if(lookAtHead.cod == TokenCod.ETIQ)   {
            Token token = lookAtHead;
            Match(TokenCod.ETIQ);
            return new NodoStringEtiq(((TokenEtiq)token).entradaTS, TokenCod.ETIQ, Tipo.NULL, 1, 1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "Etiqueta Esperada");
    }

    /*
        <String> -> STRING;
    */
    Nodo String()
    {
        if(lookAtHead.cod == TokenCod.STRING)   { 
            string s = ((SimboloString)(tabla.lista[tabla.Size() - 1])).valor;
            Match(TokenCod.STRING);
            return new NodoStringEtiq(tabla.Size() - 1, TokenCod.STRING, Tipo.NULL, -1, -1, tabla);
        }
        else
            throw new SintacticException(lookAtHead, "String Esperado");
    }

    /*
        <CondicionGoto> -> PARAB <expr> PARCER ;
    */

    Nodo CondicionGoto()
    {
        if(lookAtHead.cod == TokenCod.PARAB) {
            Match(TokenCod.PARAB);
            Token token = lookAtHead;
            Nodo expr = Expr();
            Match(TokenCod.PARCER);
            if(expr.tipo != Tipo.BOOL)   
                throw new SemanticException(token, "La condicion del goto debe devolver Bool."); 
            return expr;
        }
        else
            throw new SintacticException(lookAtHead, "Parentesis Abierto Esperado");
    }

}