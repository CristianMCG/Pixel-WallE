using System.Collections.Generic;

public class ListaPalabraClave
{
    public List<string> lista { get; private set; } = new List<string>();

    public ListaPalabraClave()
    {
        lista.Add("true");
        lista.Add("false");
        lista.Add("goto");
        lista.Add("spawn");
        lista.Add("color");
        lista.Add("size");
        lista.Add("drawline");
        lista.Add("drawcircle");
        lista.Add("drawrectangle");
        lista.Add("fill");
        lista.Add("getactualx");
        lista.Add("getactualy");
        lista.Add("getcanvassize");
        lista.Add("getcolorcount");
        lista.Add("isbrushcolor");
        lista.Add("isbrushsize");
        lista.Add("iscanvascolor");
    }

    public TokenCod Traducir(string palabra)
    {
        if(palabra == "true")
            return TokenCod.PCTRUE;
        if(palabra == "false")
            return TokenCod.PCFALSE;
        if(palabra == "goto")
            return TokenCod.PCGOTO;
        if(palabra == "spawn")
            return TokenCod.PCSPAWN;
        if(palabra == "color")
            return TokenCod.PCCOLOR;
        if(palabra == "size")
            return TokenCod.PCSIZE;
        if(palabra == "drawline")
            return TokenCod.PCDRAWLINE;
        if(palabra == "drawcircle")
            return TokenCod.PCDRAWCIRCLE;
        if(palabra == "drawrectangle")
            return TokenCod.PCDRAWRECTANGLE;
        if(palabra == "fill")
            return TokenCod.PCFILL;
        if(palabra == "getactualx")
            return TokenCod.PCGETACTUALX;
        if(palabra == "getactualy")
            return TokenCod.PCGETACTUALY;
        if(palabra == "getcanvassize")
            return TokenCod.PCGETCANVASSIZE;
        if(palabra == "getcolorcount")
            return TokenCod.PCGETCOLORCOUNT;
        if(palabra == "isbrushcolor")
            return TokenCod.PCISBRUSHCOLOR;
        if(palabra == "isbrushsize")
            return TokenCod.PCISBRUSHSIZE;
        if(palabra == "iscanvascolor")
            return TokenCod.PCISCANVASCOLOR;
        return TokenCod.ERROR;
    }

}