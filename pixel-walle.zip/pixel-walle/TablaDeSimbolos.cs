using System.Collections.Generic;

public abstract class Simbolo
{
    public string identificador { get; private set; }
    public Clase clase { get; private set; }
    public Tipo tipo { get;  set; }
    int PosTabla;
    public bool isNull { get; set; } = true;

    public Simbolo(string identificador, Clase clase, Tipo tipo, int PosTabla)
    {
        this.identificador = identificador;
        this.clase = clase;
        this.tipo = tipo;
        this.PosTabla = PosTabla;
    }

}

public class SimboloVar : Simbolo
{
    public int valor { get; set; }

    public SimboloVar(int valor, string identificador, Clase clase, Tipo tipo, int PosTabla) : base(identificador, clase, tipo, PosTabla)
    {
        this.valor = valor;
    }

}

public class SimboloEtiq : Simbolo
{
    public int valor { get; set; }
    public int linea { get; private set; }
    public int columna { get; private set; }

    public SimboloEtiq(int valor, string identificador, Clase clase, Tipo tipo, int PosTabla, int linea, int columna) : base(identificador, clase, tipo, PosTabla)
    {
        this.valor = valor;
        this.linea = linea;
        this.columna = columna;
    }

}

public class SimboloString : Simbolo
{
    public string valor { get; private set; }

    public SimboloString(string valor, string identificador, Clase clase, Tipo tipo, int PosTabla) : base(identificador, clase, tipo, PosTabla)
    {
        this.valor = valor;
    }
}

public class TablaDeSimbolos
{
    public List<Simbolo> lista { get; private set; } = new List<Simbolo>();

    public TablaDeSimbolos()
    {

    }

    public void Add(Simbolo simbolo)
    {
        lista.Add(simbolo);
    }

    public int Size()
    {
        return lista.Count;
    }

    public int Buscar(string palabra)
    {
        for(int i = 0; i < lista.Count; i++)
            if(lista[i].identificador == palabra)
                return i;
        return -1;
    }

    public void RevisarEtiqs()
    {
        for(int i = 0; i < lista.Count; i++)     {
            if(lista[i] is SimboloEtiq && lista[i].isNull)  {
                Token token = new Token(TokenCod.FINAL, ((SimboloEtiq)lista[i]).linea, ((SimboloEtiq)lista[i]).columna);
                throw new SemanticException(token, "Etiqueta <" + lista[i].identificador + ">  no definida.");
            }
        }
    }

}

public enum Clase
{
    VAR, ETIQ, STRING
}

public enum Tipo
{
    INT, BOOL, NULL
}