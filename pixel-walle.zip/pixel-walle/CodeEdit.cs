using Godot;
using System;
using System.Collections.Generic;
using System.Threading;

public partial class CodeEdit : Godot.CodeEdit
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		
	}


	public string Execute(Canvas canvas)
	{
		string final = "";
		Thread.Sleep(500);
		TablaDeSimbolos tabla = new TablaDeSimbolos();
		Scanner scanner = new Scanner(Text, tabla);
		Parser parser = new Parser(scanner, canvas, tabla);
		try 
		{
			List<Nodo> lista = parser.Parse();
    		tabla.RevisarEtiqs();
    		Runtime rte = new Runtime(lista);
    		rte.Run();
		}
		catch(LexicalException e)
		{
    		final = "Error Lexicografico <" + e.token.linea + "," + e.token.columna + ">: " + e.token.message;
		}
		catch(SintacticException e)
		{
    		final = "Error Sintactico <" + e.token.linea + "," + e.token.columna + ">: " + e.mensaje;
		}
		catch(SemanticException e)
		{
    		final = "Error Semantico <" + e.token.linea + "," + e.token.columna + ">: " + e.mensaje;
		}
		catch(RuntimeException e)
		{
    		final = "Error En Tiempo De Ejecucion: " + e.mensaje;
		}
		catch(Exception e)
		{
			final = e.Message;
		}
		
		
		if(final == "")
			final = "Compilacion y ejecucion exitosa.";

		return final;
	}


}
