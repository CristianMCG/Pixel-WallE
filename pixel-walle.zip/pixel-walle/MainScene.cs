using Godot;
using System;
using System.Threading;
using System.IO;

public partial class MainScene : Node2D
{

	CodeEdit codePlace = new CodeEdit();
	Errores windowOfErrors = new Errores();
	Redimensionar redim = new Redimensionar();
	Cargar cargar = new Cargar();
	Guardar guardar = new Guardar();
	
	Sprite2D[] rayaCanvas = new Sprite2D[260];
	Sprite2D[] rayaCanvasHorizontal = new Sprite2D[260];
	
	Sprite2D[] red = new Sprite2D[10000];
	Sprite2D[] blue = new Sprite2D[10000];
	Sprite2D[] green = new Sprite2D[10000];
	Sprite2D[] yellow = new Sprite2D[10000];
	Sprite2D[] orange = new Sprite2D[10000];
	Sprite2D[] purple = new Sprite2D[10000];
	Sprite2D[] black = new Sprite2D[10000];
	Sprite2D[] white = new Sprite2D[10000];


	Canvas canvas = new Canvas(50);


	float sizeV, sizeH;

	const float screenV = 817f, screenH = 470f;
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		
		var instCodePlace = GD.Load<PackedScene>("res://code_edit.tscn");
		codePlace = (CodeEdit)instCodePlace.Instantiate();
		AddChild(codePlace);

		var instWindowOfErrors = GD.Load<PackedScene>("res://errores.tscn");
		windowOfErrors = (Errores)instWindowOfErrors.Instantiate();
		AddChild(windowOfErrors);

		var instRedim = GD.Load<PackedScene>("res://redimensionar.tscn");
		redim = (Redimensionar)instRedim.Instantiate();
		AddChild(redim);

		var instCarga = GD.Load<PackedScene>("res://cargar.tscn");
		cargar = (Cargar)instCarga.Instantiate();
		AddChild(cargar);

		var instGuardar = GD.Load<PackedScene>("res://guardar.tscn");
		guardar = (Guardar)instGuardar.Instantiate();
		AddChild(guardar);

		var instRayaCanvas = GD.Load<PackedScene>("res://rayas_canvas.tscn");
		for(int i = 0; i < rayaCanvas.Length; i++)   {
			rayaCanvas[i] = (Sprite2D)instRayaCanvas.Instantiate();
			AddChild(rayaCanvas[i]);
			rayaCanvas[i].Position = new Vector2(-6000,-6000);
		}

		var instRayaCanvasHorizontal = GD.Load<PackedScene>("res://raya_canvas_horizontal.tscn");
		for(int i = 0; i < rayaCanvasHorizontal.Length; i++)   {
			rayaCanvasHorizontal[i] = (Sprite2D)instRayaCanvasHorizontal.Instantiate();
			AddChild(rayaCanvasHorizontal[i]);
			rayaCanvasHorizontal[i].Position = new Vector2(-6000,-6000);
		}

		var instWhite = GD.Load<PackedScene>("res://white.tscn");
		for(int i = 0; i < white.Length; i++)   {
			white[i] = (Sprite2D)instWhite.Instantiate();
			AddChild(white[i]);
			white[i].Position = new Vector2(-6000,-6000);
		}

		var instRed = GD.Load<PackedScene>("res://red.tscn");
		for(int i = 0; i < red.Length; i++)   {
			red[i] = (Sprite2D)instRed.Instantiate();
			AddChild(red[i]);
			red[i].Position = new Vector2(-6000,-6000);
		}

		var instBlue = GD.Load<PackedScene>("res://blue.tscn");
		for(int i = 0; i < blue.Length; i++)   {
			blue[i] = (Sprite2D)instBlue.Instantiate();
			AddChild(blue[i]);
			blue[i].Position = new Vector2(-6000,-6000);
		}

		var instGreen = GD.Load<PackedScene>("res://green.tscn");
		for(int i = 0; i < green.Length; i++)   {
			green[i] = (Sprite2D)instGreen.Instantiate();
			AddChild(green[i]);
			green[i].Position = new Vector2(-6000,-6000);
		}

		var instYellow = GD.Load<PackedScene>("res://yellow.tscn");
		for(int i = 0; i < yellow.Length; i++)   {
			yellow[i] = (Sprite2D)instYellow.Instantiate();
			AddChild(yellow[i]);
			yellow[i].Position = new Vector2(-6000,-6000);
		}

		var instOrange = GD.Load<PackedScene>("res://orange.tscn");
		for(int i = 0; i < orange.Length; i++)   {
			orange[i] = (Sprite2D)instOrange.Instantiate();
			AddChild(orange[i]);
			orange[i].Position = new Vector2(-6000,-6000);
		}

		var instPurple = GD.Load<PackedScene>("res://purple.tscn");
		for(int i = 0; i < purple.Length; i++)   {
			purple[i] = (Sprite2D)instPurple.Instantiate();
			AddChild(purple[i]);
			purple[i].Position = new Vector2(-6000,-6000);
		}

		var instBlack = GD.Load<PackedScene>("res://black.tscn");
		for(int i = 0; i < black.Length; i++)   {
			black[i] = (Sprite2D)instBlack.Instantiate();
			AddChild(black[i]);
			black[i].Position = new Vector2(-6000,-6000);
		}

		ConstructCanvas(canvas.GetCanvasSize(), 334.5f, -0.5f);


	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if(Input.IsActionPressed("Ejecutar"))   {
			canvas.Clear();
			canvas.Size(1);
			EliminarColores();
			string text = codePlace.Execute(canvas);
			windowOfErrors.Clear();
			windowOfErrors.ShowMessage(text);
			Paint();
		}
		if(Input.IsActionPressed("redimensionar"))   {
			Thread.Sleep(500);
			codePlace.Text = "";
			int dim = redim.getDim();
			redim.Text = "";
			GD.Print(dim);
			if(dim != -1)
				Redimensionar(dim);
			
		}
		if(Input.IsActionPressed("Cargar"))    {
			Thread.Sleep(500);
			string direccion = cargar.Text;
			string text = "";
			try
			{
				text = File.ReadAllText(direccion);
			}
			catch(Exception e) 
			{
				text = codePlace.Text;
			}
			codePlace.Text = text;
			cargar.Text = "";
		}
		if(Input.IsActionPressed("Guardar"))    {
			Thread.Sleep(500);
			string path = guardar.Text;
			try
			{
				if(!File.Exists(path))    {
					using (StreamWriter sw = File.CreateText(path))
					{
						sw.WriteLine(codePlace.Text);
					}
				}
			}
			catch(Exception e) {}
			guardar.Text = "";
		}
	}


	public void ConstructCanvas(int length, float initialX, float initialY)
	{
		int iteratorRayas = 0;
		
		int length1 = length;
		float lengthHorizontal = screenV / length;
		sizeH = lengthHorizontal;
		initialX += lengthHorizontal;
		while(length1 - 1 > 0)   {
			rayaCanvas[iteratorRayas++].Position = new Vector2(initialX, 235);
			length1--;
			initialX += lengthHorizontal;
		}



		iteratorRayas = 0;
		
		length1 = length;
		float lengthVertical = screenH / length;
		sizeV = lengthVertical;
		initialY += lengthVertical;
		while(length1 - 1 > 0)   {
			rayaCanvasHorizontal[iteratorRayas++].Position = new Vector2(743.5f, initialY);
			length1--;
			initialY += lengthVertical;
		}

		int itWhite = 0;
		for(int i = 0; i < length; i++)   {
			for(int j = 0; j < length; j++)   {
				white[itWhite].Scale = new Vector2(sizeH, sizeV);
				white[itWhite++].Position = new Vector2(335f + sizeH / 2.0f + lengthHorizontal * (float)i, sizeV / 2.0f + lengthVertical * (float)j);
			}
		}

	}


	public void Paint()  
	{
		int itRed = 0, itBlue = 0, itGreen = 0, itYellow = 0, itOrange = 0, itPurple = 0, itBlack = 0, itWhite = 0;
		for(int i = 0; i < canvas.GetCanvasSize(); i++)   {
			for(int j = 0; j < canvas.GetCanvasSize(); j++)   {
				if(canvas.pos(i,j) == Colors.RED)    {
					red[itRed].Scale = new Vector2(sizeH, sizeV);
					red[itRed++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.BLUE)    {
					blue[itBlue].Scale = new Vector2(sizeH, sizeV);
					blue[itBlue++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.GREEN)    {
					green[itGreen].Scale = new Vector2(sizeH, sizeV);
					green[itGreen++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.YELLOW)    {
					yellow[itYellow].Scale = new Vector2(sizeH, sizeV);
					yellow[itYellow++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.ORANGE)    {
					orange[itOrange].Scale = new Vector2(sizeH, sizeV);
					orange[itOrange++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.PURPLE)    {
					purple[itPurple].Scale = new Vector2(sizeH, sizeV);
					purple[itPurple++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.BLACK)    {
					black[itBlack].Scale = new Vector2(sizeH, sizeV);
					black[itBlack++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
				if(canvas.pos(i,j) == Colors.WHITE)    {
					white[itWhite].Scale = new Vector2(sizeH, sizeV);
					white[itWhite++].Position = new Vector2(335f + sizeH / 2.0f + sizeH * (float)i, sizeV / 2.0f + sizeV * (float)j);
				}
			}
		}
	}

	void EliminarColores()
	{
		for(int i = 0; i < red.Length; i++)
			red[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			blue[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			green[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			yellow[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			orange[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			purple[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			black[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < red.Length; i++)
			white[i].Position = new Vector2(-6000,-6000);
	}

	void Redimensionar(int length)
	{
		for(int i = 0; i < rayaCanvas.Length; i++)
			rayaCanvas[i].Position = new Vector2(-6000,-6000);
		for(int i = 0; i < rayaCanvasHorizontal.Length; i++)
			rayaCanvasHorizontal[i].Position = new Vector2(-6000,-6000);
		EliminarColores();
		canvas = new Canvas(length);
		ConstructCanvas(canvas.GetCanvasSize(), 334.5f, -0.5f);
	}

}
