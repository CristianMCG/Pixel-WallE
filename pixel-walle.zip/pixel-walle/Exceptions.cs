using System;

public class LexicalException : Exception
{
    public TokenError token { get; private set; }

    public LexicalException(TokenError token)
    {
        this.token = token;
    }

}

public class SintacticException : Exception
{
    public Token token { get; private set; }
    public string mensaje { get; private set; }

    public SintacticException(Token token, string mensaje)
    {
        this.token = token;
        this.mensaje = mensaje;
    }
}

public class SemanticException : Exception
{
    public Token token { get; private set; }
    public string mensaje { get; private set; }

    public SemanticException(Token token, string mensaje)
    {
        this.token = token;
        this.mensaje = mensaje;
    }

    public SemanticException(string mensaje)   
    {
        this.mensaje = mensaje;
    }

}

public class RuntimeException : Exception
{
    public string mensaje { get; private set; }

    public RuntimeException(string mensaje)
    {
        this.mensaje = mensaje;
    }

}