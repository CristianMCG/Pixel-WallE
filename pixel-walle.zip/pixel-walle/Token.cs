//Tipos de Token
public enum TokenCod 
{
    VAR, ETIQ, NUMBER, STRING, PCTRUE, PCFALSE, PCGOTO,
    OPFLECHA, OPMAS, OPMENOS, OPPOR, OPDIV, OPPOT, OPMODULO, OPAND, OPOR, 
    OPIGUAL, OPMAYORIGUAL, OPMENORIGUAL, OPMAYOR, OPMENOR, OPDISTINTO, NOT, OPXOR,
    PARAB, PARCER, CORCHAB, CORCHCER, COMA, NEWLINE,  
    PCSPAWN, PCCOLOR, PCSIZE, PCDRAWLINE, PCDRAWCIRCLE, PCDRAWRECTANGLE, PCFILL,
    PCGETACTUALX, PCGETACTUALY, PCGETCANVASSIZE, PCGETCOLORCOUNT, PCISBRUSHCOLOR, PCISBRUSHSIZE, PCISCANVASCOLOR,
    ERROR, FINAL
}

public class Token
{   
    
    public TokenCod cod { get; private set; }
    public int linea { get; private set; }
    public int columna { get; private set; }

    public Token(TokenCod cod, int linea, int columna)
    {
        this.cod = cod;
        this.linea = linea;
        this.columna = columna;
    }

    public int GetLinea()
    {
        return linea;
    }

    public int GetColumna()
    {
        return columna;
    }

}

public class TokenNumberBool : Token
{
    public int valor { get; private set; }

    public TokenNumberBool(int valor, TokenCod cod, int linea, int columna) : base(cod, linea, columna)
    {
        this.valor = valor;
    }

}

public class TokenVar : Token
{
    public int entradaTS { get; private set; }

    public TokenVar(int entradaTS, TokenCod cod, int linea, int columna) : base(cod, linea, columna)
    {
        this.entradaTS = entradaTS;
    }
}

public class TokenEtiq : Token
{
    public int entradaTS { get; private set; }

    public TokenEtiq(int entradaTS, TokenCod cod, int linea, int columna) : base(cod, linea, columna)
    {
        this.entradaTS = entradaTS;
    }
}

public class TokenError : Token
{
    public string message { get; private set; }

    public TokenError(string message, int linea, int columna) : base(TokenCod.ERROR, linea, columna)
    {
        this.message = message;
    }

}