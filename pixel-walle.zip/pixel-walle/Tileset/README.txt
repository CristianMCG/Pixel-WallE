1px solid colors and 64x64 seamless tiling paint textures.

These assets are CC0 (Public Domain), which means they are free to use with no restrictions, but no warranty of any kind is provided.

Paint texture is adapted from a public domain paper texture.

Now with a few more paint colors!