using System;
using System.IO;

public class Scanner
{
    Token TokenAnterior = new Token(TokenCod.FINAL, 0, 0);
    int linea = 1, columnaI = 0, pos = 0;
    string codigo;
    ListaPalabraClave listaPC = new ListaPalabraClave();
    TablaDeSimbolos tabla;

    public Scanner(string source, TablaDeSimbolos tabla)
    {
        codigo = source;
        codigo = codigo.ToLower();
        this.tabla = tabla;
    }

    public Token GetNextToken()
    {
        TokenAnterior = GetToken();
        if(TokenAnterior.cod == TokenCod.NEWLINE) {
            columnaI = pos;
            linea++;
        }
        return TokenAnterior;        
    }

    Token GetToken()
    {
        while(pos < codigo.Length && Saltable(pos))  
            pos++;
        int columna = pos - columnaI + 1;
        
        if(pos == codigo.Length)
            return new Token(TokenCod.FINAL, linea, columna);
        
        
        if(EsLetra(codigo[pos]))  {
            string palabra = LeerPalabra();
            
            if(EsPalabraClave(palabra))  {
                if(palabra != "true" && palabra != "false")
                    return new Token(listaPC.Traducir(palabra), linea, columna);
                else
                    return new TokenNumberBool((palabra == "true") ? 1 : 0, listaPC.Traducir(palabra), linea, columna);
            }
            
            int idx = tabla.Buscar(palabra);
            if(idx != -1)   {
                if(tabla.lista[idx].clase == Clase.VAR)
                    return new TokenVar(idx, TokenCod.VAR, linea, columna);
                if(!tabla.lista[idx].isNull && TokenAnterior.cod == TokenCod.NEWLINE)
                    throw new SemanticException(new Token(TokenCod.ETIQ, linea, columna), "Etiqueta <" + palabra + "> Redefinida");
                return new TokenEtiq(idx, TokenCod.ETIQ, linea, columna);
            }

            if(EsEtiqueta())  {
                tabla.Add(new SimboloEtiq(-1, palabra, Clase.ETIQ, Tipo.NULL, tabla.Size(), linea, columna));
                return new TokenEtiq(tabla.Size() - 1, TokenCod.ETIQ, linea, columna);
            }
            
            tabla.Add(new SimboloVar(-1, palabra, Clase.VAR, Tipo.NULL, tabla.Size()));
            return new TokenVar(tabla.Size() - 1, TokenCod.VAR, linea, columna);

        }
        
        
        if(EsNumero(codigo[pos]))  {
            string numero = LeerNumero();
            int x = int.Parse(numero);
            return new TokenNumberBool(x, TokenCod.NUMBER, linea, columna);
        }
        
        
        if(codigo[pos] == '\"')  {
            string cadena = LeerString();
            if(cadena[cadena.Length - 1] == '\"')   {
                string aux = GetString(cadena);
                tabla.Add(new SimboloString(aux, cadena, Clase.STRING, Tipo.NULL, tabla.Size()));
                return new Token(TokenCod.STRING, linea, columna);
            }
            return new TokenError("Cadena no terminada", linea, columna);
        }
        
        
        if(codigo[pos] == '<')  {
            char c = ProxChar();
            if(c == '-')  {
                pos += 2;
                return new Token(TokenCod.OPFLECHA, linea, columna);
            }  
            if(c == '=')  {
                pos += 2;
                return new Token(TokenCod.OPMENORIGUAL, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPMENOR, linea, columna);
        }
        
        if(codigo[pos] == '+')  {
            pos++;
            return new Token(TokenCod.OPMAS, linea, columna);
        }
        
        if(codigo[pos] == '-')   {
            if(TokenAnterior.cod != TokenCod.NUMBER && TokenAnterior.cod != TokenCod.VAR && TokenAnterior.cod != TokenCod.PARCER)
                return new TokenNumberBool(0, TokenCod.NUMBER, linea, columna);
            pos++;
            return new Token(TokenCod.OPMENOS, linea, columna);
        }
        
        if(codigo[pos] == '*')   {
            char c = ProxChar();
            if(c == '*')  {
                pos += 2;
                return new Token(TokenCod.OPPOT, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPPOR, linea, columna);
        }
        
        if(codigo[pos] == '/')   {
            pos++;
            return new Token(TokenCod.OPDIV, linea, columna);
        }
        
        if(codigo[pos] == '%')   {
            pos++;
            return new Token(TokenCod.OPMODULO, linea, columna);
        }
        
        if(codigo[pos] == '&')   {
            char c = ProxChar();
            if(c == '&')  {
                pos += 2;
                return new Token(TokenCod.OPAND, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un &", linea, columna);
        }
        
        if(codigo[pos] == '|')   {
            char c = ProxChar();
            if(c == '|')  {
                pos += 2;
                return new Token(TokenCod.OPOR, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un |", linea, columna);
        }
        
        if(codigo[pos] == '=')  {
            char c = ProxChar();
            if(c == '=')   {
                pos += 2;
                return new Token(TokenCod.OPIGUAL, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un =", linea, columna);
        }
        
        if(codigo[pos] == '>')  {
            char c = ProxChar();
            if(c == '=')  {
                pos += 2;
                return new Token(TokenCod.OPMAYORIGUAL, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPMAYOR, linea, columna);
        }
        
        if(codigo[pos] == '(')  {
            pos++;
            return new Token(TokenCod.PARAB, linea, columna);
        }
        
        if(codigo[pos] == ')')  {
            pos++;
            return new Token(TokenCod.PARCER, linea, columna);
        }
        
        if(codigo[pos] == '[')  {
            pos++;
            return new Token(TokenCod.CORCHAB, linea, columna);
        }
        
        if(codigo[pos] == ']')  {
            pos++;
            return new Token(TokenCod.CORCHCER, linea, columna);
        }
        
        if(codigo[pos] == ',')  {
            pos++;
            return new Token(TokenCod.COMA, linea, columna);
        }
        
        if(codigo[pos] == '\n')  {
            pos++;
            return new Token(TokenCod.NEWLINE, linea, columna);
        }
        if(codigo[pos] == '!')   {
            char c = ProxChar();
            if(c == '=')   {
                pos += 2;
                return new Token(TokenCod.OPDISTINTO, linea, columna);
            }
            pos++;
            return new Token(TokenCod.NOT, linea, columna);
        }
        if(codigo[pos] == '_')  
            return new TokenError("Los identificadores no deben empezar por _.", linea, columna);
        
        pos++;
        return new TokenError("Caracter: " + codigo[pos - 1] + " no valido.", linea, columna);
    }

    string LeerPalabra()
    {
        string palabra = "";
        while(pos < codigo.Length && EsLetraValida(codigo[pos]))   {
            palabra += codigo[pos];
            pos++;
        }
        return palabra;
    }

    bool EsLetraValida(char c)
    {
        return (EsLetra(c) || EsNumero(c) || c == '_');
    }

    bool EsLetra(char c)
    {
        return ('a' <= c && c <= 'z');
    }

    bool EsNumero(char c)
    {
        return ('0' <= c && c <= '9');
    }

    bool EsEtiqueta()
    {
        char c = NextChar(pos);
        return ((TokenAnterior.cod == TokenCod.NEWLINE && c == '\n') || 
            (TokenAnterior.cod == TokenCod.CORCHAB && c == ']'));
    }

    char NextChar(int indice)
    {
        while(indice < codigo.Length && Saltable(indice))
            indice++;
        if(indice < codigo.Length)
            return codigo[indice];
        return '\n';
    }

    bool Saltable(int index)
    {
        return (codigo[index] == ' ' || codigo[index] == '\r' || codigo[index] == '\t');
    }

    bool EsPalabraClave(string palabra)
    {
        foreach(string x in listaPC.lista)  
            if(x == palabra)
                return true;
        return false;
    }

    string LeerNumero()
    {
        string numero = "";
        while(pos < codigo.Length && EsNumero(codigo[pos]))  {
            numero += codigo[pos];
            pos++;
        }
        return numero;
    }

    string LeerString()
    {
        string cadena = "\"";
        pos++;
        while(pos < codigo.Length && codigo[pos] != '\n' && codigo[pos] != '\"')  {
            cadena += codigo[pos];
            pos++;
        }
        if(pos == codigo.Length || codigo[pos] == '\n')
            return cadena;
        pos++;
        cadena += '\"';
        return cadena; 
    }

    char ProxChar()
    {
        if(pos + 1 < codigo.Length)
            return codigo[pos + 1];
        return '~';
    }

    public string GetString(string s)
    {
        string aux = "";
        for(int i = 1; i < s.Length - 1; i++)
            aux += s[i];
        return aux;
    }

}