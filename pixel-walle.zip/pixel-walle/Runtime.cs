using System.Collections.Generic;

public class Runtime
{
    int iterador = 0;
    List<Nodo> instrucciones;

    public Runtime(List<Nodo> instrucciones)
    {
        this.instrucciones = instrucciones;
    }

    public void Run()
    {
        while(iterador < instrucciones.Count)
            instrucciones[iterador].Evaluate(ref iterador);
    }

}