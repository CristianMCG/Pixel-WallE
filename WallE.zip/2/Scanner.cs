public class Scanner
{
    Token TokenAnterior = new Token(TokenCod.FINAL, 0, 0);
    int linea = 1, columnaI = 0, pos = 0;
    string codigo;
    ListaPalabraClave listaPC = new ListaPalabraClave();

    public Scanner(string source)
    {
        codigo = File.ReadAllText(source);
        codigo = codigo.ToLower();
    }

    public Token GetNextToken()
    {
        TokenAnterior = GetToken();
        if(TokenAnterior.cod == TokenCod.NEWLINE) {
            columnaI = pos;
            linea++;
        }
        return TokenAnterior;        
    }

    Token GetToken()
    {
        while(pos < codigo.Length && Saltable(pos))  
            pos++;
        int columna = pos - columnaI + 1;
        if(pos == codigo.Length)
            return new Token(TokenCod.FINAL, linea, columna);
        if(EsLetra(codigo[pos]))  {
            string palabra = LeerPalabra();
            if(EsPalabraClave(palabra))
                return new Token(listaPC.Traducir(palabra), linea, columna);
            if(EsEtiqueta())
                return new Token(TokenCod.ETIQ, linea, columna);
            return new Token(TokenCod.VAR, linea, columna);

        }
        if(EsNumero(codigo[pos]))  {
            string numero = LeerNumero();
            return new Token(TokenCod.NUMBER, linea, columna);
        }
        if(codigo[pos] == '\"')  {
            string cadena = LeerString();
            if(cadena[cadena.Length - 1] == '\"')
                return new Token(TokenCod.STRING, linea, columna);
            return new TokenError("Cadena no terminada", linea, columna);
        }
        if(codigo[pos] == '<')  {
            char c = NextChar(pos + 1);
            if(c == '-')  {
                pos += 2;
                return new Token(TokenCod.OPFLECHA, linea, columna);
            }  
            if(c == '=')  {
                pos += 2;
                return new Token(TokenCod.OPMENORIGUAL, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPMENOR, linea, columna);
        }
        if(codigo[pos] == '+')  {
            pos++;
            return new Token(TokenCod.OPMAS, linea, columna);
        }
        if(codigo[pos] == '-')   {
            pos++;
            return new Token(TokenCod.OPMENOS, linea, columna);
        }
        if(codigo[pos] == '*')   {
            char c = NextChar(pos + 1);
            if(c == '*')  {
                pos += 2;
                return new Token(TokenCod.OPPOT, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPPOR, linea, columna);
        }
        if(codigo[pos] == '/')   {
            pos++;
            return new Token(TokenCod.OPDIV, linea, columna);
        }
        if(codigo[pos] == '%')   {
            pos++;
            return new Token(TokenCod.OPMODULO, linea, columna);
        }
        if(codigo[pos] == '&')   {
            char c = NextChar(pos + 1);
            if(c == '&')  {
                pos += 2;
                return new Token(TokenCod.OPAND, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un &", linea, columna);
        }
        if(codigo[pos] == '|')   {
            char c = NextChar(pos + 1);
            if(c == '|')  {
                pos += 2;
                return new Token(TokenCod.OPOR, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un |", linea, columna);
        }
        if(codigo[pos] == '=')  {
            char c = NextChar(pos + 1);
            if(c == '=')   {
                pos += 2;
                return new Token(TokenCod.OPIGUAL, linea, columna);
            }
            pos++;
            return new TokenError("No puede aparecer solo un =", linea, columna);
        }
        if(codigo[pos] == '>')  {
            char c = NextChar(pos + 1);
            if(c == '=')  {
                pos += 2;
                return new Token(TokenCod.OPMAYORIGUAL, linea, columna);
            }
            pos++;
            return new Token(TokenCod.OPMAYOR, linea, columna);
        }
        if(codigo[pos] == '(')  {
            pos++;
            return new Token(TokenCod.PARAB, linea, columna);
        }
        if(codigo[pos] == ')')  {
            pos++;
            return new Token(TokenCod.PARCER, linea, columna);
        }
        if(codigo[pos] == '[')  {
            pos++;
            return new Token(TokenCod.CORCHAB, linea, columna);
        }
        if(codigo[pos] == ']')  {
            pos++;
            return new Token(TokenCod.CORCHCER, linea, columna);
        }
        if(codigo[pos] == ',')  {
            pos++;
            return new Token(TokenCod.COMA, linea, columna);
        }
        if(codigo[pos] == '\n')  {
            pos++;
            return new Token(TokenCod.NEWLINE, linea, columna);
        }
        pos++;
        return new TokenError("Caracter: " + codigo[pos - 1] + " no valido", linea, columna);
    }

    string LeerPalabra()
    {
        string palabra = "";
        while(pos < codigo.Length && EsLetraValida(codigo[pos]))   {
            palabra += codigo[pos];
            pos++;
        }
        return palabra;
    }

    bool EsLetraValida(char c)
    {
        return (EsLetra(c) || EsNumero(c) || c == '_');
    }

    bool EsLetra(char c)
    {
        return ('a' <= c && c <= 'z');
    }

    bool EsNumero(char c)
    {
        return ('0' <= c && c <= '9');
    }

    bool EsEtiqueta()
    {
        char c = NextChar(pos);
        return ((TokenAnterior.cod == TokenCod.NEWLINE && c == '\n') || 
            (TokenAnterior.cod == TokenCod.CORCHAB && c == ']'));
    }

    char NextChar(int indice)
    {
        while(indice < codigo.Length && Saltable(indice))
            indice++;
        if(indice < codigo.Length)
            return codigo[indice];
        return '\n';
    }

    bool Saltable(int index)
    {
        return (codigo[index] == ' ' || codigo[index] == '\r' || codigo[index] == '\t');
    }

    bool EsPalabraClave(string palabra)
    {
        foreach(string x in listaPC.lista)  
            if(x == palabra)
                return true;
        return false;
    }

    string LeerNumero()
    {
        string numero = "";
        while(pos < codigo.Length && EsNumero(codigo[pos]))  {
            numero += codigo[pos];
            pos++;
        }
        return numero;
    }

    string LeerString()
    {
        string cadena = "\"";
        pos++;
        while(pos < codigo.Length && codigo[pos] != '\n' && codigo[pos] != '\"')  {
            cadena += codigo[pos];
            pos++;
        }
        if(pos == codigo.Length || codigo[pos] == '\n')
            return cadena;
        pos++;
        cadena += '\"';
        return cadena; 
    }

}