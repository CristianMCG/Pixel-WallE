﻿Scanner scanner = new Scanner("b.pw");
while(true)  {
    Token token = scanner.GetNextToken();
    if(token is TokenError)  
        Console.WriteLine(token.cod + " Error: " + ((TokenError)token).message + " (" + token.linea + "," + token.columna + ")");
    else
        Console.WriteLine(token.cod + " (" + token.linea + "," + token.columna + ")");
    if(token.cod == TokenCod.FINAL)
        break;
}
