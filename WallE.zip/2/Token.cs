//Tipos de Token
public enum TokenCod 
{
    VAR, ETIQ, NUMBER, STRING, PCTRUE, PCFALSE, PCGOTO,
    OPFLECHA, OPMAS, OPMENOS, OPPOR, OPDIV, OPPOT, OPMODULO, OPAND, OPOR, 
    OPIGUAL, OPMAYORIGUAL, OPMENORIGUAL, OPMAYOR, OPMENOR,
    PARAB, PARCER, CORCHAB, CORCHCER, COMA, NEWLINE,  
    PCSPAWN, PCCOLOR, PCSIZE, PCDRAWLINE, PCDRAWCIRCLE, PCDRAWRECTANGLE, PCFILL,
    PCGETACTUALX, PCGETACTUALY, PCGETCANVASSIZE, PCGETCOLORCOUNT, PCISBRUSHCOLOR, PCISBRUSHSIZE, PCISCANVASCOLOR,
    ERROR, FINAL
}

public class Token
{
    public TokenCod cod { get; private set; }
    public int linea { get; private set; }
    public int columna { get; private set; }

    public Token(TokenCod cod, int linea, int columna)
    {
        this.cod = cod;
        this.linea = linea;
        this.columna = columna;
    }

}

public class TokenError : Token
{
    public string message { get; private set; }

    public TokenError(string message, int linea, int columna) : base(TokenCod.ERROR, linea, columna)
    {
        this.message = message;
    }

}